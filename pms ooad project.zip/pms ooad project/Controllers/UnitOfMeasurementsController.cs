﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using PMS_OOAD.Models;

namespace PMS_OOAD.Controllers
{
    public class UnitOfMeasurementsController : Controller
    {
        private pharmacyManagementEntities db = new pharmacyManagementEntities();

        // GET: UnitOfMeasurements
        public ActionResult Index()
        {
            return View(db.UnitOfMeasurements.ToList());
        }

        // GET: UnitOfMeasurements/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UnitOfMeasurement unitOfMeasurement = db.UnitOfMeasurements.Find(id);
            if (unitOfMeasurement == null)
            {
                return HttpNotFound();
            }
            return View(unitOfMeasurement);
        }

        // GET: UnitOfMeasurements/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: UnitOfMeasurements/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "UnitOfMeasId,UnitOfMeas,Description")] UnitOfMeasurement unitOfMeasurement)
        {
            if (ModelState.IsValid)
            {
                db.UnitOfMeasurements.Add(unitOfMeasurement);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(unitOfMeasurement);
        }

        // GET: UnitOfMeasurements/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UnitOfMeasurement unitOfMeasurement = db.UnitOfMeasurements.Find(id);
            if (unitOfMeasurement == null)
            {
                return HttpNotFound();
            }
            return View(unitOfMeasurement);
        }

        // POST: UnitOfMeasurements/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "UnitOfMeasId,UnitOfMeas,Description")] UnitOfMeasurement unitOfMeasurement)
        {
            if (ModelState.IsValid)
            {
                db.Entry(unitOfMeasurement).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(unitOfMeasurement);
        }

        // GET: UnitOfMeasurements/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UnitOfMeasurement unitOfMeasurement = db.UnitOfMeasurements.Find(id);
            if (unitOfMeasurement == null)
            {
                return HttpNotFound();
            }
            return View(unitOfMeasurement);
        }

        // POST: UnitOfMeasurements/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            UnitOfMeasurement unitOfMeasurement = db.UnitOfMeasurements.Find(id);
            db.UnitOfMeasurements.Remove(unitOfMeasurement);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
